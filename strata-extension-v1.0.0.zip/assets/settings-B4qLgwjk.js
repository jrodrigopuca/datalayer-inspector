const a={AUTO:"auto"},e={enabled:!0,theme:a.AUTO,dataLayerNames:["dataLayer"],autoScroll:!0,maxEventsPerTab:500,defaultExpandDepth:2};export{e as D};
